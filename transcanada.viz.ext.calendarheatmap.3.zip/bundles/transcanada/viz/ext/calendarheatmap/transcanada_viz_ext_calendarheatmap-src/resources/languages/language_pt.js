sap.viz.extapi.env.Language
	.register({
		id: 'pt',
		value: {
			IDS_VERSION_PUBLIC: 'Versão Pública'
		}
	});