var sampleTemplate = {
	"id": "standard",
	"name": "Standard",
	"properties": {
		"transcanada.viz.ext.calendarheatmap": {

		}
	}
};
sap.viz.extapi.env.Template.register(sampleTemplate);