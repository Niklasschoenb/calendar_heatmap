sap.viz.extapi.env.Language
	.register({
		id: 'ru',
		value: {
			IDS_VERSION_PUBLIC: 'публичная версия'
		}
	});