sap.viz.extapi.env.Language
	.register({
		id: 'fr',
		value: {
			IDS_VERSION_PUBLIC: 'Version publique'
		}
	});